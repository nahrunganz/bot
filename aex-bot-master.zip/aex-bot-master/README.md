<div align="center">

# AEX-BOT WHATSAPP
[![CodeFactor](https://www.codefactor.io/repository/github/ibnusyawall/aex-bot/badge/master)](https://www.codefactor.io/repository/github/ibnusyawall/aex-bot/overview/master)
<details>
 <summary>Help me!</summary>

 [Saweria](https://saweria.co/donate/ibnusyawall)

 [Paypal.me](https://paypal.me/syawal24)

</details>
</div>

> Firts go to [api tools](https://api.i-tech.id) to get the key, and then open .env files then paste key obtained previously

### Requirements
  - Windows: Nodejs, Gitbash, Google Chrome
  - Linux: Nodejs, NPM, Google Chrome

### Install

```sh
$ git clone https://github.com/ibnusyawall/aex-bot.git
$ cd aex-bot
$ npm i
$ npm start
```

after running it you need to scan the qr.

> Some of the menu that we have provided, among other things:

### Group menu

| Name | Status |
| ------ | ------ |
| promote | ok |
| demote | ok |
| kick | ok |
| kickall | ok |
| getall | ok |
| kickme | ok |
| add | ok |
| del | ok |
| glink | ok |

### Education menu

| Name | Status |
| ------ | ------ |
| translate | ok |
| brainly | ok |
| wikipedia | ok |
| Nulis | ok |

### Downloader menu

| Name | Status |
| ------ | ------ |
| Youtube Downloader | ok |
| Instagram Downloader | pending |
| Pinterest Downloader | ok |
| Facebook Downloader | ok |

### Other menu

| Name | Status |
| ------ | ------ |
| Stiker | ok |
| Primbon menu | ok |
| Auto Quotes | ok |
| Quotes maker | ok |
| Auto Toxic | ok |
| Random Anime | ok |
| Random Hentai | pending |
| Jadwal Sholat | ok |
| Cek Cuaca | ok |
| Instagram Stalker | ok |
| Text to Speech | ok |
| QR Maker | ok |

### Troubleshoot
Make sure all the necessary dependencies are installed: https://github.com/puppeteer/puppeteer/blob/main/docs/troubleshooting.md

Fix Stuck on linux, install google chrome stable: 
```bash
> wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
> sudo apt install ./google-chrome-stable_current_amd64.deb
```

any question? contact me at [Whatsapp](https://wa.me/6282299265151) or [Telegram](https://t.me/isywl)